<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="spikes" tilewidth="64" tileheight="64" tilecount="16" columns="4">
 <image source="../../graphics/terrain/spikes.png" width="260" height="260"/>
</tileset>
