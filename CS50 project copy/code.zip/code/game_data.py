level_0 = {
		'terrain': './levels/0/level_0_terrain.csv',
		'blue':'./levels/0/level_0_blue.csv',
		'coins':'./levels/0/level_0_coins.csv',
		'fg pillar':'./levels/0/level_0_fgpillar.csv',
		'bg pillar':'./levels/0/level_0_bgpillar.csv',
		'spikes':'./levels/0/level_0_spikes.csv',
		'spikes2':'./levels/0/level_0_spikes2.csv',
		'chandelier':'./levels/0/level_0_chandelier.csv',
		'enemies':'./levels/0/level_0_enemies.csv',
		'constraints':'./levels/0/level_0_constraints.csv',
		'player': './levels/0/level_0_player.csv',
		'node_pos': (110,400),
		'unlock': 1,
		'node_graphics': './graphics/overworld/0'}
level_1 = {
		'terrain': './levels/1/level_1_terrain.csv',
		'blue':'./levels/1/level_1_blue.csv',
		'coins':'./levels/1/level_1_coins.csv',
		'fg pillar':'./levels/1/level_1_fgpillar.csv',
		'bg pillar':'./levels/1/level_1_bgpillar.csv',
		'spikes':'./levels/1/level_1_spikes.csv',
		'spikes2':'./levels/1/level_1_spikes2.csv',
		'chandelier':'./levels/1/level_1_chandelier.csv',
		'enemies':'./levels/1/level_1_enemies.csv',
		'constraints':'./levels/1/level_1_constraints.csv',
		'player': './levels/1/level_1_player.csv',
		'node_pos': (450,220),
		'unlock': 2,
		'node_graphics': './graphics/overworld/1'}
level_2 = {
		'terrain': './levels/2/level_2_terrain.csv',
		'blue':'./levels/2/level_2_blue.csv',
		'chandelier':'./levels/2/level_2_chandelier.csv',
		'coins':'./levels/2/level_2_coins.csv',
		'fg pillar':'./levels/2/level_2_fgpillar.csv',
		'bg pillar':'./levels/2/level_2_bgpillar.csv',
		'spikes':'./levels/2/level_2_spikes.csv',
		'spikes2':'./levels/2/level_2_spikes2.csv',
		'enemies':'./levels/2/level_2_enemies.csv',
		'constraints':'./levels/2/level_2_constraints.csv',
		'player': './levels/2/level_2_player.csv',
		'node_pos': (750,510),
		'unlock': 3,
		'node_graphics': './graphics/overworld/2'}




levels = {
	0: level_0,
	1: level_1,
	2: level_2}