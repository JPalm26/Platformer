from settings import *
import pygame

class Back:
    def __init__(self,horizon):
        self.back = pygame.image.load('./graphics/decoration/background.png').convert()
        self.bottom = pygame.image.load('./graphics/decoration/bottom.png').convert()
        self.horizon = horizon

        #stretch
        self.back = pygame.transform.scale(self.back,(screen_width,screen_height))
        self.bottom = pygame.transform.scale(self.bottom,(screen_width,screen_height))
    
    def draw(self,surface):
        surface.blit(self.back,(0,0))
    
class Mountain:
    def __init__(self,horizon):
        self.mountain= pygame.image.load('./graphics/decoration/mountain.png').convert()
        self.horizon = horizon

        #stretch
        self.mountain = pygame.transform.scale(self.mountain,(screen_width,screen_height))
       
    def draw(self,surface):
        surface.blit(self.mountain,(0,0))
    





