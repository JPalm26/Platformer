<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="chandelier" tilewidth="65" tileheight="229" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="65" height="229" source="../../graphics/terrain/chandelier.png"/>
 </tile>
</tileset>
