<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="setup_tiles" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../../graphics/character/start:end crown.png" width="130" height="65"/>
</tileset>
