<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="pillar bg" tilewidth="69" tileheight="120" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="69" height="120" source="../../graphics/terrain/pillar2/pillar copy.png"/>
 </tile>
</tileset>
